package com.ncratleos.baseimage.exception;

public class JreServiceException extends Exception {
    public JreServiceException(String message) {
        super(message);
    }

    public JreServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}