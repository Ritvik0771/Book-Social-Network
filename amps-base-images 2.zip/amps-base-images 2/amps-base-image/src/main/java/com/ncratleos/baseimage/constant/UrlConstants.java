package com.ncratleos.baseimage.constant;

/**
 * Constants for URLs used in the application.
 */
public class UrlConstants {

    /**
     * Prevent instantiation of this utility class.
     */
    private UrlConstants() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * Base URL for Docker Hub.
     */
    public static final String DOCKERHUB_BASE_URL = "https://hub.docker.com";

    /**
     * URL for fetching Alpine tags from Docker Hub.
     */
    public static final String DOCKERHUB_ALPINE_TAGS_URL = DOCKERHUB_BASE_URL + "/v2/repositories/library/alpine/tags";

    /**
     * Base URL for GitHub API.
     */
    public static final String GITHUB_BASE_URL = "https://api.github.com";

    /**
     * Repository owner and name for GitHub.    
     */
    public static final String GITHUB_REPO_OWNER_AND_NAME = "/ncratleos-swt-banking/amps-base-images";

    /**
     * URL for performing CRUD operations on files in the GitHub repository.
     */
    public static final String GITHUB_FILE_CRUD_URL = GITHUB_BASE_URL + "/repos" + GITHUB_REPO_OWNER_AND_NAME + "/contents/";

    /**
     * Alpine directory name.
     */
    public static final String ALPINE_DIRECTORY = "alpine/";

    /**
     * URL for fetching Alpine image details from GitHub.
     */
    public static final String GITHUB_ALPINE_CRUD_URL = GITHUB_FILE_CRUD_URL + ALPINE_DIRECTORY;

    public static final String GITHUB_JRE_CRUD_URL = GITHUB_FILE_CRUD_URL + "jre/correto/17/";
}
