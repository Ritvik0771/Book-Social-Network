package com.ncratleos.baseimage;

import com.ncratleos.baseimage.alpine.AlpineUpdateChecker;
import com.ncratleos.baseimage.exception.DockerhubServiceException;
import com.ncratleos.baseimage.exception.JreServiceException;
import com.ncratleos.baseimage.jre.JreUpdateChecker;

import io.micrometer.common.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@Slf4j
@SpringBootApplication
public class AmpsBaseImageApplication {

    private final AlpineUpdateChecker alpineUpdateChecker;
    private final JreUpdateChecker jreUpdateChecker;

    /**
     * Constructor for AmpsBaseImageApplication.
     *
     * @param alpineUpdateChecker the AlpineUpdateChecker to use for checking updates
     */
    public AmpsBaseImageApplication(AlpineUpdateChecker alpineUpdateChecker, JreUpdateChecker jreUpdateChecker) {
        this.alpineUpdateChecker = alpineUpdateChecker;
        this.jreUpdateChecker = jreUpdateChecker;
    }

    /**
     * Main method to run the Spring Boot application.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(AmpsBaseImageApplication.class, "jre","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");
    }

    /**
     * CommandLineRunner bean to handle command line arguments.
     *
     * @return a CommandLineRunner instance
     */
    @Bean
    public CommandLineRunner commandLineRunner() {
        return args -> {
            if (args.length == 2) {
                if(StringUtils.isNotBlank(args[0]) && StringUtils.isNotBlank(args[1])) {
                    executeCommand(args);
                } else {
                    log.error("Invalid command line arguments provided");
                }
            } else {
                log.error("Invalid number of arguments. Required 2, Provided {}", args.length);
            }
        };
    }

    /**
     * Executes the command based on the provided arguments.
     *
     * @param args the command line arguments
     * @throws DockerhubServiceException if there is an issue with the DockerHub service
     */
    private void executeCommand(String[] args) throws DockerhubServiceException, JreServiceException {
        switch (args[0]) {
            case "alpine":
                alpineUpdateChecker.checkAlpineUpdate(args[1]);
                break;
            case "jre":
                jreUpdateChecker.checkJreUpdate(args[1]);
                break;
            case "tomcat":
                log.info("Tomcat update checker not yet implemented");
                break;
            default:
                log.info("Unknown command: {}", args[0]);
        }
    }
}
