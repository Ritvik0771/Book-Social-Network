package com.ncratleos.baseimage.dto;

public class JreImageInfoDto {
    private String version;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}