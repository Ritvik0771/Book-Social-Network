package com.ncratleos.baseimage.service;

import java.io.File;
import java.io.IOException;

public class JreService {
    
    public void downloadAndExtractLatestJre(String downloadUrl, String targetDirectory) {
        try {
            // Download using wget
            Process downloadProcess = Runtime.getRuntime().exec(
                new String[]{"wget", "-O", targetDirectory + "jdk.tar.gz", downloadUrl}
            );
            downloadProcess.waitFor();

            // Extract the archive
            Process extractProcess = Runtime.getRuntime().exec(
                new String[]{"tar", "-xzf", targetDirectory + "jdk.tar.gz", "-C", targetDirectory}
            );
            extractProcess.waitFor();

        } catch (IOException | InterruptedException e) {
            throw new RuntimeException("Failed to download or extract JDK", e);
        }
    }
}
