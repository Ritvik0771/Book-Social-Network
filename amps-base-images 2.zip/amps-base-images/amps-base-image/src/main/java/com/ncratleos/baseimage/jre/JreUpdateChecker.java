// File: amps-base-image/src/main/java/com/ncratleos/baseimage/jre/JreUpdateChecker.java
package com.ncratleos.baseimage.jre;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ncratleos.baseimage.service.GithubService;
import io.micrometer.common.util.StringUtils;
import com.ncratleos.baseimage.service.JreService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import com.ncratleos.baseimage.exception.JreServiceException;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.io.File;


import static com.ncratleos.baseimage.constant.FilenameConstants.*;

@Component
@Slf4j
public class JreUpdateChecker {
    
    private final GithubService githubService;
    private final JreService jreService;
    private final ObjectMapper objectMapper;

    public JreUpdateChecker(GithubService githubService, JreService jreService, ObjectMapper objectMapper) {
        this.githubService = githubService;
        this.jreService = jreService;
        this.objectMapper = objectMapper;
    }

    public void checkJreUpdate(String githubAuthToken) throws JreServiceException {
        log.info("Checking for JRE updates...");

        try {
            // 1. Download and extract latest JDK
            String downloadUrl = "https://corretto.aws/downloads/latest/amazon-corretto-17-x64-linux-jdk.tar.gz";
            String targetDirectory = System.getProperty("java.io.tmpdir") + "/jre/";
            
            jreService.downloadAndExtractLatestJre(downloadUrl, targetDirectory);

            // 2. Get Java version
            String currentVersion = executeJavaVersionCommand();
            log.info("Current Java version: {}", currentVersion);

            // 3. Get last JRE image details from GitHub
            String lastVersion = githubService.getLastJreImageDigest(githubAuthToken);
            
            if (StringUtils.isBlank(currentVersion) || StringUtils.isBlank(lastVersion)) {
                throw new JreServiceException("Failed to get version information");
            }

            if (currentVersion.equals(lastVersion)) {
                log.info("No new version of JRE available");
                return;
            }

            // 4. Create and push new JRE image details JSON file
            createNewJreImageJsonFile(currentVersion);
            githubService.pushNewJreImageFileToRepo(githubAuthToken);

        } catch (Exception e) {
            throw new JreServiceException("Failed to check JRE update", e);
        }
    }

    private String executeJavaVersionCommand() {
        try {
            Process process = Runtime.getRuntime().exec("java -version");
            java.util.Scanner s = new java.util.Scanner(process.getInputStream()).useDelimiter("\\A");
            String output = s.hasNext() ? s.next() : "";
            return extractVersion(output);
        } catch (IOException e) {
            log.error("Failed to execute java -version command", e);
            return "";
        }
    }

    private String extractVersion(String output) {
        if (output == null || output.isEmpty()) return "";
        return output.split("\n")[0].split(" ")[2];
    }

    private void createNewJreImageJsonFile(String version) {
        Map<String, Object> data = new HashMap<>();
        data.put("version", version);

        try (FileWriter writer = new FileWriter(NEW_JRE_JSON_FILENAME)) {
            objectMapper.writeValue(new File(NEW_JRE_JSON_FILENAME), data);
            log.info("Created new JRE image details file: {}", NEW_JRE_JSON_FILENAME);
        } catch (IOException e) {
            log.error("Failed to create new JRE image details file", e);
        }
    }
}
