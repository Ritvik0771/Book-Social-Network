# amps-base-images
Repository to store base image details
