package com.ncratleos.baseimage.constant;

/**
 * Constants for filenames used in the application.
 */
public class FilenameConstants {

    /**
     * Prevent instantiation of this utility class.
     */
    private FilenameConstants() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * Filename for the new Alpine image details JSON file.
     */
    public static final String NEW_IMAGE_JSON_FILENAME = "new-alpine-image-details.json";

    /**
     * Filename for the last Alpine image details JSON file.
     */
    public static final String LAST_IMAGE_JSON_FILENAME = "last-alpine-image-details.json";
}
