package com.ncratleos.baseimage.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ncratleos.baseimage.constant.UrlConstants;
import com.ncratleos.baseimage.dto.AlpineImageInfoDto;
import com.ncratleos.baseimage.dto.DockerhubImageDto;
import com.ncratleos.baseimage.exception.DockerhubServiceException;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;

@Service
public class DockerhubService {

    /**
     * RestTemplate object
     */
    private final RestTemplate restTemplate;

    /**
     * List of tags associated with the Docker image.
     */
    private final ArrayList<String> tags = new ArrayList<>();

    /**
     * Digest of the Docker image.
     */
    private String imageDigest;

    /**
     * Identifier for the digest field in the JSON response.
     */
    private static final String DIGEST_IDENTIFIER = "digest";

    /**
     * Identifier for the name field in the JSON response.
     */
    private static final String NAME_IDENTIFIER = "name";

    /**
     * Constructor for DockerhubService.
     *
     * @param restTemplate the RestTemplate to use for HTTP requests
     */
    public DockerhubService(final RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /**
     * Retrieves the latest image details from Dockerhub.
     *
     * @return a DockerhubImageDto object containing the latest image details
     * @throws DockerhubServiceException if an error occurs while fetching the image details
     */
    public DockerhubImageDto getLatestAlpineImageDetails(AlpineImageInfoDto alpineImageInfoDto) throws DockerhubServiceException {
        DockerhubImageDto dockerhubImageDto = new DockerhubImageDto();
        try {
            ResponseEntity<String> response = restTemplate
                    .exchange(UrlConstants.DOCKERHUB_ALPINE_TAGS_URL, HttpMethod.GET, new HttpEntity<>(HttpEntity.EMPTY), String.class);
            JsonNode rootNode = new ObjectMapper().readTree(response.getBody());
            processTags(rootNode.path("results"), dockerhubImageDto, alpineImageInfoDto);
        } catch (Exception e) {
            throw new DockerhubServiceException("Failed to get latest alpine image details from dockerhub", e);
        }
        return dockerhubImageDto;
    }

    /**
     * Processes the tags from the Dockerhub response.
     *
     * @param resultsNode the JsonNode containing the tags
     * @param dockerhubImageDto the DockerhubImageDto object to populate with tag details
     */
    private void processTags(JsonNode resultsNode, DockerhubImageDto dockerhubImageDto, AlpineImageInfoDto alpineImageInfoDto) {
        if (resultsNode.isArray()) {
            for (JsonNode tagNode : resultsNode) {
                processTagNode(tagNode, dockerhubImageDto, alpineImageInfoDto);
            }
        }
        dockerhubImageDto.setTags(tags);
    }

    /**
     * Processes an individual tag node from the Dockerhub response.
     *
     * @param tagNode the JsonNode containing the tag details
     * @param dockerhubImageDto the DockerhubImageDto object to populate with tag details
     */
    private void processTagNode(JsonNode tagNode, DockerhubImageDto dockerhubImageDto, AlpineImageInfoDto alpineImageInfoDto) {
        String name = tagNode.path(NAME_IDENTIFIER).asText();
        if (name.equals("latest")) {
            imageDigest = tagNode.path(DIGEST_IDENTIFIER).asText();
            processImageNode(tagNode.path("images"), dockerhubImageDto, alpineImageInfoDto);
        }
        if (imageDigest.equals(tagNode.path(DIGEST_IDENTIFIER).asText())) {
            tags.add(tagNode.path(NAME_IDENTIFIER).asText());
        }
    }

    /**
     * Processes the image node from the Dockerhub response.
     *
     * @param imageNode the JsonNode containing the image details
     * @param dockerhubImageDto the DockerhubImageDto object to populate with image details
     */
    private void processImageNode(JsonNode imageNode, DockerhubImageDto dockerhubImageDto, AlpineImageInfoDto alpineImageInfoDto) {
        for (JsonNode image : imageNode) {
            String architecture = image.path("architecture").asText();
            String os = image.path("os").asText();

            if (alpineImageInfoDto.getPlatform().getArchitecture().equals(architecture)
                    && alpineImageInfoDto.getPlatform().getOs().equals(os)) {
                dockerhubImageDto.setDigest(image.path(DIGEST_IDENTIFIER).asText());
            }
        }
    }
}
