package com.ncratleos.baseimage.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ncratleos.baseimage.dto.AlpineImageInfoDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import static com.ncratleos.baseimage.constant.FilenameConstants.LAST_IMAGE_JSON_FILENAME;
import static com.ncratleos.baseimage.constant.FilenameConstants.NEW_IMAGE_JSON_FILENAME;
import static com.ncratleos.baseimage.constant.UrlConstants.GITHUB_ALPINE_CRUD_URL;

@Slf4j
@Service
public class GithubService {

    /**
     * RestTemplate object for making HTTP requests.
     */
    private final RestTemplate restTemplate;

    /**
     * ObjectMapper object for processing JSON.
     */
    private final ObjectMapper objectMapper;

    /**
     * Constructor for GithubService.
     *
     * @param restTemplate the RestTemplate to use for HTTP requests
     * @param objectMapper the ObjectMapper to use for JSON processing
     */
    @Autowired
    public GithubService(RestTemplate restTemplate, ObjectMapper objectMapper) {
        this.restTemplate = restTemplate;
        this.objectMapper = objectMapper;
    }

    /**
     * Pushes a new image file to the GitHub repository.
     *
     * @param githubAuthToken the GitHub authentication token
     */
    public void pushNewImageFileToRepo(final String githubAuthToken) {
        log.info(">> pushNewImageFileToRepo");
        try {
            String githubFileCrudUrl = GITHUB_ALPINE_CRUD_URL + NEW_IMAGE_JSON_FILENAME;

            // Set headers
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(githubAuthToken);

            // Push the JSON file to GitHub
            String content = new String(Files.readAllBytes(Paths.get(NEW_IMAGE_JSON_FILENAME)));
            String base64Content = Base64.getEncoder().encodeToString(content.getBytes());

            Map<String, String> jsonBody = new HashMap<>();
            jsonBody.put("message", "add new image details file");
            jsonBody.put("content", base64Content);

            // Convert map to JSON string
            String jsonString = objectMapper.writeValueAsString(jsonBody);

            // Create HTTP entity
            HttpEntity<String> requestEntity = new HttpEntity<>(jsonString, headers);

            ResponseEntity<String> response = restTemplate
                    .exchange(githubFileCrudUrl, HttpMethod.PUT, requestEntity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                log.info("File uploaded successfully to github!");
            } else {
                log.error("Failed to upload file: {}", response.getStatusCode());
            }
        } catch (Exception e) {
            log.error("Exception occurred while pushing new image file to repo: {}", e.getMessage());
        }
    }

    /**
     * Retrieves the last image digest from the GitHub repository.
     *
     * @param githubAuthToken the GitHub authentication token
     * @return the last image digest as a String
     */
    public String getLastImageDigest(final String githubAuthToken) {
        log.info(">> getLastImageDigest");
        try {
            String githubFileCrudUrl = GITHUB_ALPINE_CRUD_URL + LAST_IMAGE_JSON_FILENAME;

            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(githubAuthToken);

            HttpEntity<String> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate
                    .exchange(githubFileCrudUrl, HttpMethod.GET, requestEntity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                return getDigest(response);
            } else {
                log.debug("Failed to fetch last alpine image digest: {}", response.getStatusCode());
            }
        } catch (Exception e) {
            log.error("Exception occurred while fetching last alpine image digest with status code: {}", e.getMessage());
        }
        return "";
    }

    /**
     * Extracts the digest from the GitHub response.
     *
     * @param response the ResponseEntity containing the GitHub response
     * @return the digest as a String
     */
    private String getDigest(ResponseEntity<String> response) {
        log.info(">> getDigest");
        JsonNode root;
        JsonNode rootNode;
        try {
            // Parse JSON response
            root = objectMapper.readTree(response.getBody());

            // Decode Base64 content
            String decodedContent = new String(Base64.getMimeDecoder().decode(root.path("content").asText()));

            rootNode = objectMapper.readTree(decodedContent);
            return rootNode.path("digest").asText();
        } catch (JsonProcessingException e) {
            log.error("Exception occurred while parsing json: {}", e.getMessage());
        }
        return "";
    }

    public AlpineImageInfoDto getAlpineManifest(final String githubAuthToken) {
        log.info(">> getAlpineManifest");
        JsonNode root;
        JsonNode rootNode;
        AlpineImageInfoDto alpineImageInfoDto = null;
        try {
            String githubFileCrudUrl = GITHUB_ALPINE_CRUD_URL + "alpine-manifest.json";

            HttpHeaders headers = new HttpHeaders();
            headers.setBearerAuth(githubAuthToken);

            HttpEntity<String> requestEntity = new HttpEntity<>(headers);

            ResponseEntity<String> response = restTemplate
                    .exchange(githubFileCrudUrl, HttpMethod.GET, requestEntity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {

                // Parse JSON response
                root = objectMapper.readTree(response.getBody());

                // Decode Base64 content
                String decodedContent = new String(Base64.getMimeDecoder().decode(root.path("content").asText()));
                rootNode = objectMapper.readTree(decodedContent);
                alpineImageInfoDto = objectMapper.treeToValue(rootNode, AlpineImageInfoDto.class);
            } else {
                log.debug("Failed to fetch alpine manifest: {}", response.getStatusCode());
            }
        } catch (Exception e) {
            log.error("Exception occurred while fetching alpine manifest with status code: {}", e.getMessage());
        }
        return alpineImageInfoDto;
    }
}
