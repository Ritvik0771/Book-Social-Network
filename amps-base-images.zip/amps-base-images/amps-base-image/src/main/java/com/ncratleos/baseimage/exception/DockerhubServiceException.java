package com.ncratleos.baseimage.exception;

/**
 * Exception thrown when there is an issue with the Docker Hub service.
 */
public class DockerhubServiceException extends Exception {
    /**
     * Constructs a new DockerhubServiceException with the specified detail message and cause.
     *
     * @param message the detail message.
     * @param cause the cause of the exception.
     */
    public DockerhubServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new DockerhubServiceException with the specified detail message.
     *
     * @param message the detail message.
     */
    public DockerhubServiceException(String message) {
        super(message);
    }
}
