package com.ncratleos.baseimage.alpine;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ncratleos.baseimage.dto.AlpineImageInfoDto;
import com.ncratleos.baseimage.dto.DockerhubImageDto;
import com.ncratleos.baseimage.exception.DockerhubServiceException;
import com.ncratleos.baseimage.service.DockerhubService;
import com.ncratleos.baseimage.service.GithubService;
import io.micrometer.common.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.ncratleos.baseimage.constant.FilenameConstants.NEW_IMAGE_JSON_FILENAME;

/**
 * This class checks for updates to the Alpine Docker image.
 */
@Slf4j
@Component
public class AlpineUpdateChecker {

    /**
     * Service for interacting with GitHub.
     */
    private final GithubService githubService;

    /**
     * Service for interacting with DockerHub.
     */
    private final DockerhubService dockerhubService;

    /**
     * Details of the DockerHub image.
     */
    private DockerhubImageDto dockerhubImageDto;

    /**
     * ObjectMapper for JSON processing.
     */
    private final ObjectMapper objectMapper;

    /**
     * Constructor for AlpineUpdateChecker.
     *
     * @param githubService the GitHub service to use
     * @param dockerhubService the DockerHub service to use
     */
    public AlpineUpdateChecker(GithubService githubService, DockerhubService dockerhubService, ObjectMapper objectMapper) {
        this.githubService = githubService;
        this.dockerhubService = dockerhubService;
        this.objectMapper = objectMapper;
    }

    /**
     * Checks for updates to the Alpine Docker image.
     *
     * @param githubAuthToken the GitHub authentication token
     * @throws DockerhubServiceException if there is an issue with the DockerHub service
     */
    public void checkAlpineUpdate(final String githubAuthToken)
            throws DockerhubServiceException {

        AlpineImageInfoDto alpineImageInfoDto = this.githubService.getAlpineManifest(githubAuthToken);
        dockerhubImageDto = this.dockerhubService.getLatestAlpineImageDetails(alpineImageInfoDto);
        log.debug("dockerhubImageDto : {}", dockerhubImageDto);
        //read last image details json file from github
        String lastImageDigest = githubService.getLastImageDigest(githubAuthToken);

        if(StringUtils.isBlank(dockerhubImageDto.getDigest()) || StringUtils.isBlank(lastImageDigest)) {
            throw new DockerhubServiceException("Failed to get latest image details from dockerhub");
        }

        if(dockerhubImageDto.getDigest().equals(lastImageDigest)) {
            log.info("No new version of Alpine available");
            return;
        }

        try {
            // Create and push the new image details JSON file to GitHub
            createNewAlpineImageJsonFile();
            githubService.pushNewImageFileToRepo(githubAuthToken);
        } catch (Exception e) {
            log.error("Exception occurred while checking Alpine update: {}", e.getMessage(), e);
        }
    }

    /**
     * Creates a new JSON file with the latest image details.
     */
    private void createNewAlpineImageJsonFile() {
        // Create the JSON file in the specified format
        Map<String, Object> data = new HashMap<>();
        data.put("digest", dockerhubImageDto.getDigest());
        data.put("tags", dockerhubImageDto.getTags());
        try(FileWriter writer = new FileWriter(System.getenv("GITHUB_ENV"), true)) {
            objectMapper.writeValue(new File(NEW_IMAGE_JSON_FILENAME), data);
            log.info("Digest written to " + NEW_IMAGE_JSON_FILENAME);
            data.put("update", "true");
            for (Map.Entry<String, Object> entry : data.entrySet()){
                if (entry.getValue() instanceof List) {
                    writer.write(entry.getKey() + "=" + objectMapper.writeValueAsString(entry.getValue()) + "\n");
                } else {
                    writer.write(entry.getKey() + "=" + entry.getValue().toString() + "\n");
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred while creating new image JSON file: {}", e.getMessage());
        }
    }
}
