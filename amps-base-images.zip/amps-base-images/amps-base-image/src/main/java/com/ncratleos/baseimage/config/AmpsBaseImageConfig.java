package com.ncratleos.baseimage.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;

/**
 * Configuration class for AMPS Base Image.
 */
@Configuration
public class AmpsBaseImageConfig {

    /**
     * Creates a RestClient bean.
     *
     * @return a new instance of RestClient
     */
    @Bean
    public RestClient restClient() {
        return RestClient.create();
    }

    /**
     * Creates a RestTemplate bean.
     *
     * @return a new instance of RestTemplate
     */
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
