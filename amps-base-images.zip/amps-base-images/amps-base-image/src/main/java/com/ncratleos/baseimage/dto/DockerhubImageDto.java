package com.ncratleos.baseimage.dto;

import lombok.Data;

import java.util.List;

/**
 * Data Transfer Object representing a Docker Hub image.
 */
@Data
public class DockerhubImageDto {
    /**
     * Digest of the Docker Hub image.
     */
    private String digest;

    /**
     * List of tags associated with the Docker Hub image.
     */
    private List<String> tags;
}
