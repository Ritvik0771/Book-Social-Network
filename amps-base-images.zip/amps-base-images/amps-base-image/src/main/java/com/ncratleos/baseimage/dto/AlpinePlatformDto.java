package com.ncratleos.baseimage.dto;

import lombok.Data;

/**
 * Data Transfer Object for Alpine Platform.
 */
@Data
public class AlpinePlatformDto {
    /**
     * The architecture of the Alpine platform.
     */
    private String architecture;

    /**
     * The operating system of the Alpine platform.
     */
    private String os;
}
