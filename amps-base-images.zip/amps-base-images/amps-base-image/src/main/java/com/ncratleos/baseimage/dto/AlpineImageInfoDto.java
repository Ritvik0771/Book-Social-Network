package com.ncratleos.baseimage.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Data Transfer Object for Alpine Image Information.
 */
@Data
public class AlpineImageInfoDto {
    /**
     * Path to the image.
     */
    @JsonProperty("image-path")
    private String imagePath;

    /**
     * Version of the image.
     */
    @JsonProperty("image-version")
    private String imageVersion;

    /**
     * Platform details of the image.
     */
    private AlpinePlatformDto platform;
}
