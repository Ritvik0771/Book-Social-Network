package com.ncratleos.baseimage;

import com.ncratleos.baseimage.alpine.AlpineUpdateChecker;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.CommandLineRunner;
import org.springframework.test.context.bean.override.mockito.MockitoBean;

import static org.mockito.Mockito.*;

/**
 * Test class for AmpsBaseImageApplication.
 */
@SpringBootTest
class AmpsBaseImageApplicationTests {

    /**
     * Mocked AlpineUpdateChecker bean.
     */
    @MockitoBean
    private AlpineUpdateChecker alpineUpdateChecker;

    /**
     * Autowired CommandLineRunner bean.
     */
    @Autowired
    private CommandLineRunner commandLineRunner;

    /**
     * Test the 'alpine update' command.
     * @throws Exception if an error occurs during command execution.
     */
    @Test
    void testAlpineCommand() throws Exception {
        String[] args = {"alpine", "update"};
        commandLineRunner.run(args);
        verify(alpineUpdateChecker, times(1)).checkAlpineUpdate("update");
    }

    /**
     * Test an unknown command.
     * @throws Exception if an error occurs during command execution.
     */
    @Test
    void testUnknownCommand() throws Exception {
        String[] args = {"unknown"};
        commandLineRunner.run(args);
        // Verify no interactions with alpineUpdateChecker
        verifyNoInteractions(alpineUpdateChecker);
    }

    /**
     * Test with no arguments.
     * @throws Exception if an error occurs during command execution.
     */
    @Test
    void testNoArguments() throws Exception {
        String[] args = {};
        commandLineRunner.run(args);
        // Verify no interactions with alpineUpdateChecker
        verifyNoInteractions(alpineUpdateChecker);
    }
}
