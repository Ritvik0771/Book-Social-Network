package com.ncratleos.baseimage.service;

import com.ncratleos.baseimage.dto.AlpineImageInfoDto;
import com.ncratleos.baseimage.dto.AlpinePlatformDto;
import com.ncratleos.baseimage.dto.DockerhubImageDto;
import com.ncratleos.baseimage.exception.DockerhubServiceException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Test class for DockerhubService.
 */
class DockerhubServiceTests {

    /**
     * Mocked RestTemplate.
     */
    @Mock
    private RestTemplate restTemplate;

    /**
     * Injected DockerhubService.
     */
    @InjectMocks
    private DockerhubService dockerhubService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Test getting the latest image details from Dockerhub.
     * @throws DockerhubServiceException if an error occurs during the request.
     */
    @Test
    void testGetLatestAlpineImageDetails() throws DockerhubServiceException {
        String jsonResponse = "{ \"results\": [ { \"name\": \"latest\", \"digest\": \"sha256:12345\", \"images\": [ { \"architecture\": \"amd64\", \"os\": \"linux\", \"digest\": \"sha256:12345\" } ] }, { \"name\": \"1.0\", \"digest\": \"sha256:12345\" } ] }";
        AlpinePlatformDto alpinePlatformDto = new AlpinePlatformDto();
        alpinePlatformDto.setOs("linux");
        alpinePlatformDto.setArchitecture("amd64");
        AlpineImageInfoDto alpineImageInfoDto = new AlpineImageInfoDto();
        alpineImageInfoDto.setPlatform(alpinePlatformDto);
        ResponseEntity<String> responseEntity = ResponseEntity.ok(jsonResponse);

        when(restTemplate.exchange(any(String.class), any(HttpMethod.class), any(HttpEntity.class), eq(String.class)))
                .thenReturn(responseEntity);

        DockerhubImageDto dockerhubImageDto = dockerhubService.getLatestAlpineImageDetails(alpineImageInfoDto);

        assertNotNull(dockerhubImageDto);
        assertEquals("sha256:12345", dockerhubImageDto.getDigest());
        assertTrue(dockerhubImageDto.getTags().contains("1.0"));
    }

    /**
     * Test exception handling when getting the latest image details from Dockerhub.
     */
    @Test
    void testGetLatestAlpineImageDetailsThrowsException() {
        AlpineImageInfoDto alpineImageInfoDto = new AlpineImageInfoDto();
        when(restTemplate.exchange(any(String.class), any(HttpMethod.class), any(HttpEntity.class), eq(String.class)))
                .thenThrow(new RuntimeException("Service unavailable"));

        assertThrows(DockerhubServiceException.class, () -> dockerhubService.getLatestAlpineImageDetails(alpineImageInfoDto));
    }
}
