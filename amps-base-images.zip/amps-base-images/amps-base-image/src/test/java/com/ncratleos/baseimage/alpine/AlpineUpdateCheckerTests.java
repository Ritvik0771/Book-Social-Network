package com.ncratleos.baseimage.alpine;

import com.ncratleos.baseimage.dto.AlpineImageInfoDto;
import com.ncratleos.baseimage.dto.DockerhubImageDto;
import com.ncratleos.baseimage.exception.DockerhubServiceException;
import com.ncratleos.baseimage.service.DockerhubService;
import com.ncratleos.baseimage.service.GithubService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

/**
 * Test class for AlpineUpdateChecker.
 */
class AlpineUpdateCheckerTests {

    /**
     * Mocked GithubService.
     */
    @Mock
    private GithubService githubService;

    /**
     * Mocked DockerhubService.
     */
    @Mock
    private DockerhubService dockerhubService;

    @Mock
    private AlpineImageInfoDto alpineImageInfoDto;

    /**
     * Injected AlpineUpdateChecker.
     */
    @InjectMocks
    private AlpineUpdateChecker alpineUpdateChecker;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Test checking for a new Alpine update when a new version is available.
     * @throws Exception if an error occurs during the update check.
     */
    @Test
    void testCheckAlpineUpdate_NewVersionAvailable() throws Exception {
        DockerhubImageDto dockerhubImageDto = new DockerhubImageDto();
        dockerhubImageDto.setDigest("digest123");
        when(githubService.getAlpineManifest(anyString())).thenReturn(alpineImageInfoDto);
        when(dockerhubService.getLatestAlpineImageDetails(alpineImageInfoDto)).thenReturn(dockerhubImageDto);
        when(githubService.getLastImageDigest(anyString())).thenReturn("digest456");

        alpineUpdateChecker.checkAlpineUpdate("dummyToken");

        verify(githubService, times(1)).pushNewImageFileToRepo(anyString());
    }

    /**
     * Test exception handling during the Alpine update check.
     * @throws Exception if an error occurs during the update check.
     */
    @Test
    void testCheckAlpineUpdate_ExceptionHandling() throws Exception {
        when(githubService.getAlpineManifest(anyString())).thenReturn(alpineImageInfoDto);
        when(dockerhubService.getLatestAlpineImageDetails(alpineImageInfoDto)).thenReturn(new DockerhubImageDto());

        assertThrows(DockerhubServiceException.class, () -> alpineUpdateChecker.checkAlpineUpdate("dummyToken"));

        verify(githubService, never()).pushNewImageFileToRepo(anyString());
    }
}
