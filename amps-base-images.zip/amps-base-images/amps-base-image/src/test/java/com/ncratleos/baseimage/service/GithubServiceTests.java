package com.ncratleos.baseimage.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

/**
 * Test class for GithubService.
 */
class GithubServiceTests {

    /**
     * Mocked RestTemplate.
     */
    @Mock
    private RestTemplate restTemplate;

    /**
     * Mocked ObjectMapper.
     */
    @Mock
    private ObjectMapper objectMapper;

    /**
     * Injected GithubService.
     */
    @InjectMocks
    private GithubService githubService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Test getting the last image digest from GitHub.
     * @throws Exception if an error occurs during the request.
     */
    @Test
    void testGetLastImageDigest_Success() throws Exception {
        String githubAuthToken = "testToken";
        String responseBody = "{\"content\": \"" + Base64.getEncoder().encodeToString("{\"digest\": \"testDigest\"}".getBytes()) + "\"}";

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(githubAuthToken);

        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<String> responseEntity = new ResponseEntity<>(responseBody, HttpStatus.OK);
        when(restTemplate.exchange(anyString(), eq(HttpMethod.GET), eq(requestEntity), eq(String.class)))
                .thenReturn(responseEntity);

        when(objectMapper.readTree(responseBody)).thenReturn(new ObjectMapper().readTree(responseBody));
        when(objectMapper.readTree(anyString())).thenReturn(new ObjectMapper().readTree("{\"digest\": \"testDigest\"}"));

        String digest = githubService.getLastImageDigest(githubAuthToken);

        assertEquals("testDigest", digest);
    }
}
